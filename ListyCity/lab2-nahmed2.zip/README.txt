Natasha Osmani
nahmed2
Lab H01

1. Deleting and item from listview on click
    How to dynamically remove items from ListView on a click? (2019, April 11). 
        Www.Tutorialspoint.Com. https://www.tutorialspoint.com/how-to-dynamically-remove-items-from-listview-on-a-click

    Asked by kavitha, & answer by esharp. (2010, April 1). 
        Remove ListView items in Android. Stack Overflow. 
        https://stackoverflow.com/questions/2558591/remove-listview-items-in-android/5344958#5344958

2. Preventing app from restarting when rotating phone
    Handle configuration changes |. (n.d.). Android Developers. 
        https://developer.android.com/guide/topics/resources/runtime-changes.html

3. Adding an item to list view  
    Asked by Muhammed Misir, & answered by Nick Cardoso. (2015, August 16). 
        Add item in a ListView. Stack Overflow. 
        https://stackoverflow.com/questions/32036672/add-item-in-a-listview/32037022#32037022
